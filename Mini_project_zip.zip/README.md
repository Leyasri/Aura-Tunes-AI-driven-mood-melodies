# Latex_Report_Template

## Creators

Copyright © 2020, Template Latex Report

- vivekadi <vivek.adishesha@gmail.com>,
- keshavbharadwaj <keshavbharadwaj@gmail.com>, 
- anirudhmanikandan <anirudhmanikandan98@gmail.com>,
- sharathnpayyadi <sharathnp1998@gmail.com>,
- chiranjitpatel <chiranjitpatel08@gmail.com>
- vivekurankar <vivekurankar@gmail.com>,
- sourav <souravadi1998@gmail.com>,
- suhas <suhasraikar46@gmail.com>,
- sumanthbhat <sumubhat123@gmail.com>
- vibharavi <vibha274@gmail.com>


## Template

This project contains files for the templates of:

1. Project Report 
2. Intership Report 

Developed for Undergraduate, Postgraduate and PhD Thesis reports. The images and formatting are catered to 
Visvesvaraya Technological University affiliated Institutions.

Can be modified to suit other Institutional formats by accessing the **.cls & **.tex source files.